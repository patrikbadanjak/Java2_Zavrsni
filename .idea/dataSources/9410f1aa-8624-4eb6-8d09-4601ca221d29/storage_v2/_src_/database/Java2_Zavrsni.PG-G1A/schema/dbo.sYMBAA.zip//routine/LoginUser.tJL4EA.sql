create proc LoginUser
	@email nvarchar(30), @password nvarchar(128)
		as
			select IDEmployee, FirstName, LastName, Email, RoleID
			from Employee
			where Pwd = @password
go

