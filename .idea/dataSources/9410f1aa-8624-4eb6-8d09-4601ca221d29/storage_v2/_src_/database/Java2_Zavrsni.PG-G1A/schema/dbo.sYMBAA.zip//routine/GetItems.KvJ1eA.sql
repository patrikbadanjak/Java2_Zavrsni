create proc GetItems
	AS
		select IDItem, ItemName, Stock, Price
		from Item
go

