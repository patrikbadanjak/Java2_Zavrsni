create proc GetItem
	@idItem int
		as
			select ItemName, Stock, Price
			from Item
			where IDItem = @idItem
go

